# Databricks notebook source
# MAGIC %md
# MAGIC ## 1. Create a Dataframe using a connector

# COMMAND ----------

file_df =(
  spark.read.format("csv")
  .option("header", "true")
  .option("inferShema","true")
  .load("/Volumes/dev/spark_db/datasets/spark_programming/data/sf-fire-calls.csv")
)

# COMMAND ----------

json_file_df=(
    spark.read.format("json")
    .load(path="/Volumes/dev/spark_db/datasets/spark_programming/data/sf-fire-calls.csv")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Create a Dataframe reading a Spark table

# COMMAND ----------

table_df = spark.table("dev.spark_db.sf_fire_calls")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Create a Dataframe reading the result of a SQL query

# COMMAND ----------

table_name ="dev.spark_db.sf_fire_calls"

sql_df = spark.sql(f"SELECT * FROM {table_name} LIMIT 5")

# COMMAND ----------

sql_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Create a dataframe from a Python list

# COMMAND ----------

from datetime import *

data_list_schema = 'id long, name string, joining_date date, salary double, created timestamp'

date_list = [
    (1, "Henil",date(2020,1,1),1000.20,datetime.now()),
    (2, "Dwip",date(2020,1,1),959.20,datetime.now()),
    (3, "Ravi",date(2020,1,1),777.55,datetime.now())
]

list_df = spark.createDataFrame(date_list,data_list_schema)

list_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Create a single column dataframe from a range

# COMMAND ----------

range_df = spark.range(1000,1010,2)
range_df.display()