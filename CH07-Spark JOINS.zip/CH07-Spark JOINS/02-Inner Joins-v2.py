# Databricks notebook source
# MAGIC %sql
# MAGIC select m.member_id, first_name, last_name, facility_id, slot, start_time
# MAGIC from dev.spark_db.bookings as b inner join dev.spark_db.members as m on m.member_id = b.member_id
# MAGIC where m.last_name = "Smith" and b.slot > 5
# MAGIC order by m.first_name asc, b.slot desc

# COMMAND ----------

from pyspark.sql.functions import expr, col

members_df = spark.table("dev.spark_db.members").alias("m")
bookings_df = spark.table("dev.spark_db.bookings").alias("b")

#join_expr = expr("m.menber_id == b.member_id")
join_expr = col("m.member_id") == col("b.member_id")

reports_df = (
    members_df.join(bookings_df, join_expr, "inner")
        .filter("m.last_name == 'Smith' and b.slot > 5")
        .select("m.member_id", "m.first_name", "m.last_name", "b.facility_id", "b.slot", "b.start_time")
        .orderBy("m.first_name", col("b.slot").desc())
)

reports_df.display()