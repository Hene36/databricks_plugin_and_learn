# Databricks notebook source
from pyspark.sql.functions import col, expr

member_df = (
    spark.table("dev.spark_db.members")
    .filter("member_id > 0")
    .select("member_id","first_name","last_name")
    .alias("m")
)

bookings_df = spark.table("dev.spark_db.bookings").alias("b")
facilities_df = spark.table("dev.spark_db.facilities").alias("f")

latest_member_bookings_df = (
    member_df.lateralJoin(
        bookings_df.where("b.member_id == m.member_id")
        .orderBy(col("start_time").desc())
        .limit(1), None, "left")
    .select("m.member_id","m.first_name","m.last_name","b.facility_id","b.start_time","b.slot")
    .alias("mb")
)

result_df =(
    latest_member_bookings_df.join(facilities_df, on =expr("mb.facility_id == f.facility_id"), how = "left")
    .select("mb.first_name","mb.last_name","f.facility_name","mb.slot","mb.start_time")
)

result_df.display()

# COMMAND ----------

students_df = spark.table("dev.spark_db.offline_var_students").alias("s")

result_df = (
    students_df.lateralJoin(spark.tvf.variant_explode("s.skills")
                            .selectExpr("cast(value:Skill as string) as skill", "cast(value:YearsOfExperience as int) as experience"))
                .where("skill like '%Spark%' and experience > 1")
                .select("id", "first_name", "last_name", "skill", "experience")
)

result_df.display()