# Databricks notebook source
# MAGIC %md
# MAGIC **Join types in Apache Spark**
# MAGIC 1. Inner Join - Return only the rows that have matching values on both sides
# MAGIC 2. Outer Joins
# MAGIC - Left - Returns all rows from the left side and matching rows from the right side
# MAGIC - Right - Returns all rows from the right side and matching rows from the left side
# MAGIC - Full - Return all matching and non-matching rows from both sides
# MAGIC 3. Natural Join - Automatically create join criteria on the same column names (Applies to Inner and Outer Joins)
# MAGIC 4. Cross Join - Join without any join criteria (all possible combinations)
# MAGIC 5. Self Join - Join a table with itself (Applies to Inner, Outer, and Cross Joins)
# MAGIC 6. Semi Join - Take records from the left side when it matches with the right side
# MAGIC 7. Anti Join - Take records from the left side when it doesn not match with the right side
# MAGIC 8. Lateral Join - Each row from the driving table is used to subquery the derived table

# COMMAND ----------

# MAGIC %md
# MAGIC 1. Load data from files and create the following tables.
# MAGIC - facilities -> facilities.csv
# MAGIC - members -> members.csv
# MAGIC - bookings -> bookings.csv
# MAGIC Choose appropriate data types to best represent the data fields.

# COMMAND ----------

# MAGIC %md
# MAGIC **2. Define schema**

# COMMAND ----------

facilities_schema = """facility_id INT, facility_name STRING, member_cost DOUBLE, guest_coast DOUBLE, inital_outlay DOUBLE, monthly_maintainance DOUBLE"""

member_schema = """ member_id INT, last_name STRING, first_name STRING, address STRING, zip_code STRING, telephone STRING, recommended_by STRING, joining_date DATE"""

booking_schema = """ booking_id INT, facility_id INT, member_id INT, start_time TIMESTAMP, slot INT"""

# COMMAND ----------

# MAGIC %md
# MAGIC **3. Load facilities table**

# COMMAND ----------

facilities_df = (
    spark.read.format("csv")
    .option("header", "true")
    .schema(facilities_schema)
    .load("/Volumes/dev/spark_db/datasets/spark_programming/data/facilities.csv")
)
facilities_df.write.mode("overwrite").saveAsTable("dev.spark_db.facilites")

# COMMAND ----------

# MAGIC %md
# MAGIC **4. Load members table**

# COMMAND ----------

member_df = (
    spark.read.format("csv")
    .option("header","true")
    .schema(member_schema)
    .load("/Volumes/dev/spark_db/datasets/spark_programming/data/members.csv")
)

member_df.write.mode("overwrite").saveAsTable("dev.spark_db.members")

# COMMAND ----------

# MAGIC %md
# MAGIC **5. Load bookings table**

# COMMAND ----------

booking_df = (
    spark.read.format("csv")
    .option("header","true")
    .schema(booking_schema)
    .load("/Volumes/dev/spark_db/datasets/spark_programming/data/bookings.csv")
)
booking_df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable("dev.spark_db.bookings")