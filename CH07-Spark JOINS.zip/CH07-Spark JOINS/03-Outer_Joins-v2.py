# Databricks notebook source
from pyspark.sql.functions import expr, col

members_df = spark.table("dev.spark_db.members").alias("m")
bookings_df = spark.table("dev.spark_db.bookings").alias("b")

result_df = (
    members_df.join(bookings_df, expr("m.member_id=b.member_id"), "left")
        .where("m.first_name == 'Darren' and m.last_name == 'Smith'")
        .select("m.member_id", "m.first_name", "m.last_name", "m.address", "b.facility_id", "b.slot")
        .orderBy(col("b.slot").desc_nulls_first())
)

result_df.display()

# COMMAND ----------

from pyspark.sql.functions import expr, col

members_df =(
    spark.table("dev.spark_db.members")
    .where("first_name == 'Darren' and last_name == 'Smith'")
)

bookings_df = spark.table("dev.spark_db.bookings")
facilities_df = spark.table("dev.spark_db.facilities")

joined_df =(
    members_df.alias("m")
    .join(bookings_df.alias("b"),expr("m.member_id = b.member_id"),"left")
    .join(facilities_df.alias("f"),expr("b.facility_id = f.facility_id"),"left")
)

results_df =(
    joined_df.selectExpr(
        "f.facility_name","b.slot",
        "b.slot * f.member_cost as booking_amount",
        "b.start_time","b.member_id",
        "concat_ws(' ',m.first_name, m.last_name) as member_name",
        "m.telephone", "m.address"
    ).orderBy(col("slot").desc_nulls_first())
)
results_df.display()

# COMMAND ----------

# DBTITLE 1,Cell 3
from pyspark.sql.functions import expr

facilities_df = spark.table("dev.spark_db.facilities")
bookings_df = spark.table("dev.spark_db.bookings").filter("slot>10")

result_df = (
    bookings_df.join(facilities_df, bookings_df.facility_id == facilities_df.facility_id, "right")
    .select(facilities_df.facility_name,
            facilities_df.member_cost,
            facilities_df.guest_cost,
            bookings_df.start_time,
            bookings_df.slot
    )
)

result_df.display()

# COMMAND ----------

from pyspark.sql.functions import expr

members_df = (
    spark.table("dev.spark_db.members")
    .filter("member_id !=0 and recommended_by is null")
    .alias("m")
)

bookings_df = (
    spark.table("dev.spark_db.bookings")
    .filter("slot > 8")
    .alias("b")
)

facilities_df = (
    spark.table("dev.spark_db.facilities").alias("f")
)

full_join_df = members_df.join(bookings_df,expr("m.member_id == b.member_id"), "full")

result_df = (
    full_join_df.join(facilities_df, expr("b.facility_id == f.facility_id"),"left")
    .select("b.booking_id","f.facility_name","b.slot","m.first_name","m.last_name","m.address")
    .orderBy(expr("b.slot").asc_nulls_last(), expr("m.first_name").asc_nulls_last())
)

display(result_df)