# Databricks notebook source
from pyspark.sql.functions import col

bookings_df = spark.table("dev.spark_db.bookings").filter("slot > 5")
members_df = spark.table("dev.spark_db.members").filter("last_name == 'Smith'")
facilities_df = spark.table("dev.spark_db.facilities")

bmf_df = bookings_df.join(members_df, ["member_id"], "inner").join(facilities_df, "facility_id")

report_df = (
    bmf_df.selectExpr("member_id", "first_name", "last_name", "facility_name", "slot",
                "slot * member_cost as booking_amount", "start_time")
        .orderBy("first_name", col("booking_amount").desc())
)

display(report_df)

# COMMAND ----------

members_df = spark.table("dev.spark_db.members").filter("member_id != 0 and recommended_by is null")
bookings_df = spark.table("dev.spark_db.bookings").filter("slot > 8")
facilities_df = spark.table("dev.spark_db.facilities")

joined_df = (
    members_df.join(bookings_df,"member_id","full")
    .join(facilities_df,"facility_id","left")
)

report_df = (
    joined_df.select(
        "booking_id", "facility_name","slot",
        "first_name","last_name","address").orderBy("slot","first_name")
)

display(report_df)

# COMMAND ----------

members_df = spark.table("dev.spark_db.members").filter("member_id > 0")
facilities_df = spark.table("dev.spark_db.facilities")

reports_df = (
    members_df.crossJoin(facilities_df)
    .select("first_name","last_name","facility_name")
)
display(reports_df)

# COMMAND ----------

from pyspark.sql.functions import expr, concat_ws

members_df = spark.table("dev.spark_db.members")

report_df = (
    members_df.alias("m")
        .join(members_df.alias("r"), expr("m.recommended_by==r.member_id"), "inner")
        .select("m.member_id",
                concat_ws(" ", "m.first_name", "m.last_name").alias("Member Name"),
                concat_ws(" ", "r.first_name", "r.last_name").alias("Recommended By"))
)

report_df.display()

# COMMAND ----------

members_df = spark.table("dev.spark_db.members").filter("member_id > 0").alias("m")
bookings_df = spark.table("dev.spark_db.bookings").alias("b")

report_df = (
    members_df.join(bookings_df, expr("m.member_id=b.member_id"), "left_semi")
    .select("member_id","first_name","last_name","address")
)

report_df.display()

# COMMAND ----------

members_df = spark.table("dev.spark_db.members").filter("member_id > 0").alias("m")
bookings_df = spark.table("dev.spark_db.bookings").alias("b")

report_df = (
    members_df.join(bookings_df, expr("m.member_id=b.member_id"), "left_anti")
    .select("member_id","first_name","last_name","address")
)

report_df.display()