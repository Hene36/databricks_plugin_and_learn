# Databricks notebook source
bookings_df = spark.table("dev.spark_db.bookings")
facilities_df = spark.table("dev.spark_db.facilities")
members_df = spark.table("dev.spark_db.members")

club_bookings_df =(
    bookings_df.join(facilities_df,"facility_id")
    .join(members_df,"member_id","left")
    .selectExpr("booking_id",
                "case when member_id==0 then 'Guest Member' else concat_ws(' ', first_name, last_name) end as member_name",
                "facility_name","start_time",
                "case when member_id==0 then slot * guest_cost else slot * member_cost end as booking_amount"
    )
)
club_bookings_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Calculate total earnings and average booking value.

# COMMAND ----------

# MAGIC %md
# MAGIC **1.1 Using sql like expressions**

# COMMAND ----------

result_df = (
    club_bookings_df.selectExpr("sum(booking_amount) as total_earning",
                                "avg(booking_amount) as avg_booking_value")
)
result_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **1.2 Using column expressions**

# COMMAND ----------

from pyspark.sql.functions import sum, avg

result_df = (
    club_bookings_df.select(sum("booking_amount").alias("total_earning"),
                            avg("booking_amount").alias("avg_booking_value"))
)
result_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **1.3 Using aggregate transformation**

# COMMAND ----------



# COMMAND ----------

from pyspark.sql.functions import sum, avg

result_df = (
    club_bookings_df.agg(sum("booking_amount").alias("total_earning"),
                            avg("booking_amount").alias("avg_booking_value"))
)
result_df.display()