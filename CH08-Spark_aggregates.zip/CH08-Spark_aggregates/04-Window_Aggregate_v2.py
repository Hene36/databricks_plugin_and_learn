# Databricks notebook source
from pyspark.sql.functions import expr, sum

bookings_df = spark.table("dev.spark_db.bookings")
facilities_df = spark.table("dev.spark_db.facilities")
members_df = spark.table("dev.spark_db.members")

booking_summary_df = (
    bookings_df.join(facilities_df, "facility_id").join(members_df, "member_id", "left")
    .where("month(start_time) = 7 AND year(start_time) = 2022")
    .withColumns(
        {
            "booked_by": expr("case when member_id == 0 then 'Guest' else 'Member' end"),
            "booking_date": expr("to_date(start_time)"),
            "booking_amount": expr("case when member_id == 0 then slot * guest_cost else slot * member_cost end")
        }
    )
    .groupBy("booked_by", "booking_date")
    .agg(sum("booking_amount").alias("revenue"))
    .orderBy("booking_date")
)
booking_summary_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **1.2 Add running total to your report.**

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import sum

window_spec = (
    Window.partitionBy("booked_by")
    .orderBy("booking_date")
    .rowsBetween(Window.unboundedPreceding, Window.currentRow)
)

result_df = (
    booking_summary_df.withColumn("running_total",sum("revenue").over(window_spec))
)

result_df.display()

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import avg, round

window_spec = (
    Window.partitionBy("booked_by")
    .orderBy("booking_date")
    .rowsBetween(-2, Window.currentRow)
)

result_df = (
    booking_summary_df.withColumn("3_day_avg",
                                  round(avg("revenue").over(window_spec),2))
)
result_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **Show top 3 revenue dates from guests and members.**

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import rank, col

window_spec = (
    Window.partitionBy("booked_by")
    .orderBy(col("revenue").desc())
)

result_df =(
    booking_summary_df.withColumn("rank",rank().over(window_spec))
    .where("rank <=3")
    .drop("rank")
)

result_df.display()