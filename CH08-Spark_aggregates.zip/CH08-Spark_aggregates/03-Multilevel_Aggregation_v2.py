# Databricks notebook source
bookings_df = spark.table("dev.spark_db.bookings")
facilities_df = spark.table("dev.spark_db.facilities")
members_df = spark.table("dev.spark_db.members")

club_bookings_df = (
    bookings_df.join(facilities_df,"facility_id").join(members_df,"member_id","left")
    .selectExpr("member_id","booking_id",
                "case when member_id==0 then 'Guest Member' else concat_ws(' ', first_name, last_name) end as member_name","facility_name","start_time",
                "case when member_id==0 then slot * guest_cost else slot * member_cost end as booking_amount")
)

club_bookings_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **Monthly report for FY 2022**

# COMMAND ----------

from pyspark.sql.functions import sum, month, col

result_df = (
    club_bookings_df.where("year(start_time) == 2022")
    .withColumn("mnth", month("start_time"))
    .rollup("mnth")
    .agg(sum("booking_amount").alias("revenue"))
    .orderBy(col("mnth").asc_nulls_last())
)

result_df.display()

# COMMAND ----------

from pyspark.sql.functions import sum, col ,expr

result_df = (
    club_bookings_df.where("year(start_time) == 2022")
    .withColumn("revenue_from", expr("case when member_id == 0 then 'Guest' else 'Member' end"))
    .rollup("revenue_from","facility_name")
    .agg(sum("booking_amount").alias("revenue"))
    .orderBy(col("revenue_from").asc_nulls_last(),
             col("facility_name").asc_nulls_last()
    )
)
result_df.display()

# COMMAND ----------

from pyspark.sql.functions import sum, col ,expr

result_df = (
    club_bookings_df.where("year(start_time) == 2022")
    .withColumn("revenue_from", expr("case when member_id == 0 then 'Guest' else 'Member' end"))
    .cube("revenue_from","facility_name")
    .agg(sum("booking_amount").alias("revenue"))
    .orderBy(col("revenue_from").asc_nulls_last(),
             col("facility_name").asc_nulls_last())
)
result_df.display()


# COMMAND ----------

# DBTITLE 1,Cell 6
from pyspark.sql.functions import sum, col ,expr, lit

result_df = (
    club_bookings_df.where("year(start_time)==2022")
    .withColumn("revenue_from", expr("case when member_id == 0 then 'Guest' else'Member' end"))
    .groupBy("revenue_from","facility_name").agg(sum("booking_amount").alias("revenue"))
    .unionByName(
        club_bookings_df.where("year(start_time)==2022")
        .withColumn("revenue_from", expr("case when member_id == 0 then 'Guest' else'Member' end"))
        .groupBy("revenue_from").agg(sum("booking_amount").alias("revenue"))
        .withColumn("facility_name", lit(None).cast("string"))
    )
    .orderBy(col("revenue_from").asc_nulls_last(),
             col("facility_name").asc_nulls_last())
)
result_df.display()