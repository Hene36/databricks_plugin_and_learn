# Databricks notebook source
bookings_df = spark.table("dev.spark_db.bookings")
facilities_df = spark.table("dev.spark_db.facilities")
members_df = spark.table("dev.spark_db.members")

club_bookings_df =(
    bookings_df.join(facilities_df,"facility_id").join(members_df,"member_id","left")
    .selectExpr(
        "booking_id",
        "case when member_id == 0 then 'Guest Member' else concat_ws(' ', first_name, last_name) end as member_name",
        "facility_name","start_time",
        "case when member_id == 0 then slot * guest_cost else slot * member_cost end as  booking_amount"
    )
    
)

club_bookings_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **Top five members**

# COMMAND ----------

from pyspark.sql import functions as F

result_df = (
    club_bookings_df.where("member_name !='Guest Member'")
    .groupBy("member_name")
    .agg(F.sum("booking_amount").alias("total_booking_amount"))
    )

result_df.display()

# COMMAND ----------

from pyspark.sql.functions import expr, col 

result_df =(
    club_bookings_df.where("member_name !='Guest Member'")
    .groupBy("member_name")
    .agg(expr("sum(booking_amount)").alias("total_booking_amount"))
    .orderBy(col("total_booking_amount").desc())
    .limit(5)
    )

result_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **more than 2500 amount**

# COMMAND ----------

from pyspark.sql.functions import expr, col

result_df = (
    club_bookings_df.where("member_name !='Guest Member'")
    .groupBy("member_name","facility_name")
    .agg(expr("sum(booking_amount) as total_booking_amount"))
    .where("total_booking_amount > 2500")
    )

result_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC