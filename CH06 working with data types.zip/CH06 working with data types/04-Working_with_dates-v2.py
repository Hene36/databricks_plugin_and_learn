# Databricks notebook source
# MAGIC %md
# MAGIC **Working with dates
# MAGIC Date functions**

# COMMAND ----------

# MAGIC %md
# MAGIC 1. Date funtions 

# COMMAND ----------

# MAGIC %md
# MAGIC 1. **_Requirement_**
# MAGIC - You are given a dataframe as below

# COMMAND ----------

# DBTITLE 1,Cell 4
from pyspark.sql.functions import concat_ws

data_list = [(2022, 5, 8), (9999, 12 ,31), (-9999,1,1), (1000, 1 ,1),
             (-1000, 1 ,1), (193, 5, 25),  (99, 5, 25), (1000, 2, 29)]

df = (spark.createDataFrame(data_list).toDF("Y","M","D")
      .withColumn("date_str", concat_ws("-","Y","M","D")))
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Convert strings to date
# MAGIC - Spark validates the date against the Proleptic Gregorian calendar.
# MAGIC - The negative years are BC, and the positive values are AD in Gregorian calander.
# MAGIC - Valid dates are taken, and invalid dates throw an exception or taken as null

# COMMAND ----------

# DBTITLE 1,Cell 6
from pyspark.sql.functions import expr

df = (
  df.withColumn("valid_date",expr("try_to_date(date_str, 'yyyy-M-d')")).drop("Y","M","D")
)

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3. Add, Subtract days and months to date

# COMMAND ----------

from pyspark.sql.functions import date_add, date_sub, add_months, date_diff

df = (
    df.withColumns({
        "add_5_dates":date_add("valid_date",5),
        "sub_5_days": date_sub("valid_date",5),
        "add_5_months": add_months("valid_date",5),
        "sub_5_months": add_months("valid_date",-5)
    })
)

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Current date, date difference, and interval ##

# COMMAND ----------

from pyspark.sql.functions import current_date, date_diff, col

df = df.withColumns({
     "current_date": current_date(),
     "delta_date_days": date_diff("add_5_months","valid_date"),
     "delta_date_interval": col("current_date")- col("valid_date")
})

# COMMAND ----------

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Format date

# COMMAND ----------

from pyspark.sql.functions import date_format

dt =(
     df.withColumn("fmt_date", date_format("valid_date","dd MM yyyy"))
)

dt.display()

# COMMAND ----------

# MAGIC %md
# MAGIC