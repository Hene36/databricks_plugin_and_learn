# Databricks notebook source
# MAGIC %md
# MAGIC **Working with numbers**
# MAGIC - Using mathematical expressions
# MAGIC - Using mathematical functions
# MAGIC - Using aggregate functions

# COMMAND ----------

# MAGIC %md
# MAGIC ### **1. Load invoices data to a dataframe**

# COMMAND ----------

retail_df = (
    spark.read.format("csv")
    .option("header","true")
    .option("inferSchema","true")
    .load("/Volumes/dev/spark_db/datasets/spark_programming/data/invoices.csv")
)
display(retail_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2. Calculate total_value for each invoice line item

# COMMAND ----------

# MAGIC %md
# MAGIC 2.1 Simple approach of creating expressions

# COMMAND ----------

from pyspark.sql.functions import expr

retail_df.withColumn("total_value", expr("round(quantity * unitprice,2)")).display()

# COMMAND ----------

# MAGIC %md
# MAGIC 2.2 Using column expressions

# COMMAND ----------

from pyspark.sql.functions import round, col

retail_df.withColumn("total_value", round(col("Quantity")* col("UnitPrice"),2)).display()

# COMMAND ----------

# MAGIC %md
# MAGIC 2.3 Using expression variable - 1

# COMMAND ----------

total_value_expr_1 = round(col("quantity")* col("unitprice"),2)
retail_df.withColumn("total_value",total_value_expr_1).display()

# COMMAND ----------

# MAGIC %md
# MAGIC 2.4 Using expression variable - 2

# COMMAND ----------

total_value_expr_2 = expr("round(quantity * unitprice,2)")
retail_df.withColumn("total_value",total_value_expr_2).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Perform the following exploratory analysis on invoices data
# MAGIC 1. Can we make invoice numbers a numeric field?
# MAGIC 2. Analyize quantity to identify potentially invalid records
# MAGIC 3. Analyze unit price to identify potentially invalid records

# COMMAND ----------

# MAGIC %md
# MAGIC **3.1 Analyze using dataframe summary**
# MAGIC
# MAGIC

# COMMAND ----------

retail_df.summary().select('summary', 'InvoiceNo','Quantity','UnitPrice').display()

# COMMAND ----------

# MAGIC %md
# MAGIC **3.2 Using sql functions**

# COMMAND ----------

from pyspark.sql.functions import min, max, percentile

retail_df.select(min("unitprice"),expr("max(unitprice)"), percentile("unitprice",0.99)).display()

# COMMAND ----------

# MAGIC %md
# MAGIC 3. Perform the following exploratory analysis on invoices data
# MAGIC - Can we make invoice numbers a numeric field?
# MAGIC - Analyize quantity to identify potentially invalid records
# MAGIC - Analyze unit price to identify potentially invalid records

# COMMAND ----------

# MAGIC %md
# MAGIC 3.1 Analyze using dataframe summary
# MAGIC
# MAGIC Available statistics are:
# MAGIC
# MAGIC   count - mean - stddev - min - max - approximate percentiles

# COMMAND ----------

retail_df.summary().select('summary','InvoiceNo','Quantity','UnitPrice').display()

# COMMAND ----------

from pyspark.sql.functions import min, max, percentile

retail_df.select(min("unitprice"), max("unitprice"), percentile("unitprice", 0.99)).display()