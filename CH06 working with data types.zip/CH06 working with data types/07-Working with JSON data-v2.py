# Databricks notebook source
# MAGIC %md
# MAGIC 1. Requirement
# MAGIC - Read data from students_online.json file and load into online_students table.

# COMMAND ----------

online_students_schema = """
    ID string, FirstName string, LastName string,
    Address struct<AddressLine1 string, AddressLine2 string, City string, State string, Country string, Pin string>,
    Skills array<struct<Skill string, YearsOfExperience string>>,
    Contacts map<string, string>
    """

online_students_df = (
    spark.read.format("json")
        .schema(online_students_schema)
        .load("/Volumes/dev/spark_db/datasets/spark_programming/data/students_online.json")
)

online_students_df.display()
online_students_df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable("dev.spark_db.online_students")

# COMMAND ----------

online_students_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Requirement
# MAGIC **Perform the following analysis**
# MAGIC
# MAGIC - What is country wise student count.
# MAGIC - Find all students with more than 1 years of Spark knowledge
# MAGIC - Find all students who didn't provide phone or whatsapp

# COMMAND ----------

# MAGIC %md
# MAGIC 2.1 What is country wise student count.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT Address.Country, count(*) as count
# MAGIC FROM dev.spark_db.online_students
# MAGIC GROUP BY Address.Country

# COMMAND ----------

# MAGIC %md
# MAGIC 2.2 Find all students with more than 1 years of Spark knowledge

# COMMAND ----------

# MAGIC %sql
# MAGIC with online_students_skills(
# MAGIC   select id, firstname, LastName, explode(Skills) as skills
# MAGIC   from dev.spark_db.online_students)
# MAGIC select id, firstname, lastname, skills.*
# MAGIC from online_students_skills
# MAGIC where LOWER(skills.skill) like "%spark%" and skills.YearsOfExperience > 1

# COMMAND ----------

# MAGIC %md
# MAGIC **2.3 Find all students who didn't provide phone or whatsapp**

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select id, FirstName, LastName, Contacts['email'] as email
# MAGIC from dev.spark_db.online_students
# MAGIC where Contacts['phone'] is null and Contacts ['whatsapp'] is null 