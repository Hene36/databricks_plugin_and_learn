# Databricks notebook source
# MAGIC %md
# MAGIC **Working with timestamp**
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Requirement
# MAGIC - You are given the below dataframes

# COMMAND ----------

# DBTITLE 1,Cell 3
date_list_1 = [(1,"2022-05-18T10:30:30.0000"),(2,"2022-05-19T10:30:30.0000")]
date_list_2 = [(1,"18-05-2022 10:30:30.0000"),(2,"19-05-2022 10:30:30.0000")]
date_list_3 = [(1,"2022-05-18 10:30:30.0000"),(2,"19-05-2022 10:30:30.0000")]

df_1 = (spark.createDataFrame(date_list_1).toDF("id","string_time"))
df_2 = (spark.createDataFrame(date_list_2).toDF("id","string_time"))
df_3 = (spark.createDataFrame(date_list_3).toDF("id","string_time"))

# COMMAND ----------

# MAGIC %md
# MAGIC 2.1 covert the df_1 to timestamp

# COMMAND ----------

from pyspark.sql.functions import to_timestamp, col

df_1.select("string_time",
            to_timestamp("string_time","yyyy-MM-dd'T'HH:mm:ss.SSSS").alias("valid_time")
            ).display()

# COMMAND ----------

# MAGIC %md
# MAGIC **2.2 Convert the df_2 to time**

# COMMAND ----------

df_2.selectExpr(
    "string_time",
     "to_timestamp(string_time,'dd-MM-yyyy HH:mm:ss.SSSS') as valid_time"
).display()

# COMMAND ----------

# MAGIC %md
# MAGIC **2.3 Convert the df_3 to time**

# COMMAND ----------

df_3.selectExpr(
    "string_time",
    "try_to_timestamp(string_time,'yyyy-MM-dd HH:mm:ss.SSSS') as valid_time"
).display()

# COMMAND ----------

# MAGIC %md
# MAGIC **3. Timezone information**
# MAGIC - A timestamp without timezone information is incomplete.
# MAGIC - Spark offers two data types for timestamp
# MAGIC - TIMESTAMP
# MAGIC - TIMESTAMP_NTZ
# MAGIC - For TIMESTAMP, Spark assumes session timezone as the default when timezone is not specified
# MAGIC - Session timezone is specified as spark.sql.session.timeZone

# COMMAND ----------

# MAGIC %md
# MAGIC **3.1 What is your default session timezone?**

# COMMAND ----------

spark.conf.get("spark.sql.session.timeZone")

# COMMAND ----------

# MAGIC %md
# MAGIC **4. Working with NTZ data**

# COMMAND ----------

# MAGIC %md
# MAGIC 4.1 Load machine-events-no-tz.csv file and show the data

# COMMAND ----------

event_nz_schema = "component string, event_time string, reading string"

event_nz_df = (
    spark.read.format("csv")
    .option("header","true")
    .schema(event_nz_schema)
    .load("/Volumes/dev/spark_db/datasets/spark_programming/data/machine-events-no-tz.csv")
)
event_nz_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC 4.2 Parse te event_time to a TIMESTAMP_NTZ value

# COMMAND ----------

# DBTITLE 1,Cell 17
from pyspark.sql.functions import to_timestamp_ntz, lit

event_valid_ntz_df =(
    event_nz_df.withColumn("event_valid_ntz_df",to_timestamp_ntz("event_time",lit("dd-MM-yyyy HH:mm:ss.SSSSSSSSS")))
)

event_valid_ntz_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **4.3 event_time_ntz field to a valid timestamp value
# MAGIC - Assume the event_time_ntz is MST time**

# COMMAND ----------

from pyspark.sql.functions import convert_timezone, lit

stz = spark.conf.get("spark.sql.session.timeZone")

events_df = (
    event_valid_ntz_df.withColumn("event_time_tz", to_timestamp(convert_timezone(lit("MST"),lit(stz),"event_valid_ntz_df")))
)
events_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Working with TZ data

# COMMAND ----------

# MAGIC %md
# MAGIC 5.1 Load machine-events-with-tz.csv file and show the data

# COMMAND ----------

event_tz_schema = "component string, event_time_tz_str string, reading string"

event_tz_df = (
    spark.read.format("csv")
    .option("header","true")
    .schema(event_tz_schema)
    .load("/Volumes/dev/spark_db/datasets/spark_programming/data/machine-events-with-tz.csv")
)

display(event_tz_df)

# COMMAND ----------

# MAGIC %md
# MAGIC **5.2 Parse the event_time field to a valid timestamp value**
# MAGIC - Timezone information is provided in the data file

# COMMAND ----------

from pyspark.sql.functions import to_timestamp

events_data_df = (
    event_tz_df.withColumn("event_time_tz", to_timestamp("event_time_tz_str","dd-MM-yyyy HH:mm:ss.SSSZ"))
)
events_data_df.display()