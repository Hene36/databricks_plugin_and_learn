# Databricks notebook source
# MAGIC %md
# MAGIC ## 1. Requirement
# MAGIC - Read data from students_offline.csv file and load into offline_students_raw table.

# COMMAND ----------

offline_students_schema = "ID string, FirstName string, LastName string, Address string, Skills string, Contacts string"

offline_students_raw_df = (
    spark.read.format("csv")
        .option("header", "true")
        .option("quote", "\"")
        .option("escape", "\"")
        .schema(offline_students_schema)
        .load("/Volumes/dev/spark_db/datasets/spark_programming/data/students_offline.csv")
)

offline_students_raw_df.display()
offline_students_raw_df.write.mode("overwrite").saveAsTable("dev.spark_db.offline_students_raw")

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Analysis Requirement
# MAGIC - We want to know country wise student count.

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC with offline_students(
# MAGIC   select id, from_json(address,
# MAGIC       """struct<AddressLine1 string,
# MAGIC         AddressLine2 string,
# MAGIC         City string,
# MAGIC         Country string,
# MAGIC         Pin string,
# MAGIC         State string>
# MAGIC       """) as address
# MAGIC   from dev.spark_db.offline_students_raw
# MAGIC )
# MAGIC select address.country, count(*) as count
# MAGIC from offline_students
# MAGIC group by address.country

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Requirement
# MAGIC Prepare an offline_students table which is ready for analysis
# MAGIC
# MAGIC Complex Data Types in Spark
# MAGIC
# MAGIC - Struct
# MAGIC - Array
# MAGIC - Map

# COMMAND ----------

from pyspark.sql.functions import from_json

address_schema = "struct<AddressLine1 string, AddressLine2 string, City string, Country string ,Pin string, State string>"
skills_schema = "array<struct<Skill string, YearsOfExperience string>>"
contacts_schema = "map<string, string>"

offline_students_df =(
    offline_students_raw_df.withColumns({
        "address": from_json("address",address_schema),
        "skills": from_json("skills",skills_schema),
        "contacts": from_json("contacts",contacts_schema)
    })
)
offline_students_df.display()
offline_students_df.write.mode("overwrite").saveAsTable("dev.spark_db.offline_students")


# COMMAND ----------

# MAGIC %md
# MAGIC 4. Requirement
# MAGIC Perform the following analysis
# MAGIC
# MAGIC - What is country wise student count.
# MAGIC - Find all students with more than 1 years of Spark knowledge
# MAGIC - Find all students who didn't provide phone or whatsapp

# COMMAND ----------

# MAGIC %md
# MAGIC 4.1 What is country wise student count.

# COMMAND ----------

# MAGIC %sql
# MAGIC select address.Country, count(*) as count 
# MAGIC from dev.spark_db.offline_students
# MAGIC group by address.Country

# COMMAND ----------

# MAGIC %md
# MAGIC 4.2 Find all students with more than 1 years of Spark knowledge

# COMMAND ----------

# DBTITLE 1,Cell 11
# MAGIC %sql
# MAGIC     
# MAGIC
# MAGIC with offline_students_skills(
# MAGIC   select id, FirstName, LastName, explode(skills) as skills
# MAGIC   from dev.spark_db.offline_students
# MAGIC )
# MAGIC
# MAGIC select id, firstname, lastname, skills.*
# MAGIC from offline_students_skills
# MAGIC where skills.Skill like "%Spark%" and skills.YearsOfExperience > 1

# COMMAND ----------

# MAGIC %md
# MAGIC 4.3 Find all students who didn't provide phone or whatsapp

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT ID, FirstName, LastName, contacts['email']
# MAGIC FROM dev.spark_db.offline_students
# MAGIC WHERE contacts['phone'] is NULL AND contacts['whatsapp'] is NULL