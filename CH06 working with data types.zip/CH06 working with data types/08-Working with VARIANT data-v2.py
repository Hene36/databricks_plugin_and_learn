# Databricks notebook source
# MAGIC %md
# MAGIC ## 1. Requirement
# MAGIC **Read data from students_offline.csv file and load into offline_students_raw table.**

# COMMAND ----------

offline_students_schema = "id string, first_name string, last_name string, address string, skills string, contacts string"

offline_students_raw_df = (
  spark.read.format("csv")
  .option("header", "true")
  .option("quote","\"")
  .option("escape","\"")
  .schema(offline_students_schema)
  .load("/Volumes/dev/spark_db/datasets/spark_programming/data/students_offline.csv")
)

offline_students_raw_df.write.mode("overwrite").option("overwriteSchema","true").saveAsTable("dev.spark_db.offline_students_raw")

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Requirement
# MAGIC - Prepare an offline_var_students table which is ready for analysis

# COMMAND ----------

# DBTITLE 1,Cell 4
from pyspark.sql.functions import parse_json

offline_students_df =(
    offline_students_raw_df.withColumns({
        "address": parse_json("address"),
        "skills": parse_json("skills"),
        "contacts": parse_json("contacts")
    })
)

offline_students_df.write.mode("overwrite").saveAsTable("dev.spark_db.offline_var_students")

# COMMAND ----------

# MAGIC %md
# MAGIC 3.Requirement
# MAGIC Perform the following analysis
# MAGIC
# MAGIC 1. What is country wise student count.
# MAGIC 2. Find all students with more than 1 years of Spark knowledge
# MAGIC 3. Find all students who didn't provide phone or whatsapp

# COMMAND ----------

# MAGIC %md
# MAGIC 2.1 What is country wise student count.

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select cast(address:Country as string), count(*) as count
# MAGIC from dev.spark_db.offline_var_students
# MAGIC group by cast(address:Country as string)

# COMMAND ----------

# MAGIC %md
# MAGIC 2.2 Find all students with more than 1 years of Spark knowledge

# COMMAND ----------

# DBTITLE 1,Cell 9
# MAGIC %sql
# MAGIC WITH offline_students_skills AS (
# MAGIC   SELECT id, first_name, last_name, 
# MAGIC          CAST(value:Skill AS STRING) AS skill, 
# MAGIC          CAST(value:YearsOfExperience AS INT) AS yearsofexperience
# MAGIC   FROM dev.spark_db.offline_var_students, 
# MAGIC        LATERAL variant_explode_outer(skills)
# MAGIC )
# MAGIC SELECT * 
# MAGIC FROM offline_students_skills
# MAGIC WHERE skill LIKE '%Spark%' AND yearsofexperience > 1

# COMMAND ----------

# MAGIC %md
# MAGIC 2.3 Find all students who didn't provide phone or whatsapp

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select id, first_name, last_name, contacts:email
# MAGIC from dev.spark_db.offline_var_students
# MAGIC where contacts:phone is null and contacts:whatsapp is null