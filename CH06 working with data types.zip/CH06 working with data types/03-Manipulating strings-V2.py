# Databricks notebook source
# MAGIC %md
# MAGIC Working with String
# MAGIC String Manipulation Functions

# COMMAND ----------

from pyspark.sql.functions import concat_ws, to_date

df = spark.createDataFrame([('02','05','1998')]).toDF("day","month","year")

date_expr = to_date(concat_ws("-","year","month","day"))

df.select(date_expr.alias("date")).display()

# COMMAND ----------

from pyspark.sql.functions import *

df = (spark.createDataFrame([("Sanjay","Kalra",25,"July",1982,19408.0)]).toDF("first_name","last_name","day","month","year","salary"))

salary_fmt = format_number("salary",2).alias("salary")

text_fmt = format_string("Mr. %s %s was born %dth %s of %d.",
                         "first_name","last_name","day","month","year").alias("fun_text")

df.select(salary_fmt,text_fmt).display()

# COMMAND ----------

from pyspark.sql.functions import translate

df = spark.createDataFrame([("Benga`li Market","110001"),("Abu~godi","560030")]).toDF("address","pin")

df.withColumn("address",translate("address","`~","")).display()
