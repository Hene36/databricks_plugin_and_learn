# Databricks notebook source
# MAGIC %sql
# MAGIC select * from dev.spark_db.flight_time_raw 

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Read data to create a dataframe

# COMMAND ----------

fligt_time_raw_df = spark.read.table("dev.spark_db.flight_time_raw")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Develop logic to transform CRS_DEP_TIME to an interval

# COMMAND ----------

from pyspark.sql.functions import *

step_1_df = (
    fligt_time_raw_df.withColumns(
        {
            "CRS_DEP_TIME_HH": expr("substring(lpad(CRS_DEP_TIME, 4, '0'), 1, 2)"),
            "CRS_DEP_TIME_MM": expr("substring(lpad(CRS_DEP_TIME, 4, '0'), 3, 2)")
        }
    )
)

step_2_df = (
    step_1_df.withColumns({
         "CRS_DEP_TIME_NEW": expr("cast(concat(CRS_DEP_TIME_HH,':',CRS_DEP_TIME_MM) AS INTERVAL HOUR TO MINUTE)")
    })
)

# COMMAND ----------

step_2_df.limit(2).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Develop a reusable function

# COMMAND ----------

def get_interval(hhmm_value):
    from pyspark.sql.functions import expr

    return expr(f"""
                cast(concat(left(lpad({hhmm_value},4,'0'),2),':',
                             right(lpad({hhmm_value},4,'0'),2))
                             AS INTERVAL HOUR TO MINUTE)
                """)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Apply function to dataframe

# COMMAND ----------

result_df =(
    fligt_time_raw_df.withColumns(
        {
            "CRS_DEP_TIME":get_interval("CRS_DEP_TIME"),
            "DEP_TIME":get_interval("DEP_TIME"),
            "WHEELS_ON":get_interval("WHEELS_ON"),
            "CRS_ARR_TIME":get_interval("CRS_ARR_TIME"),
            "ARR_TIME":get_interval("ARR_TIME")
        }
    )
)

# COMMAND ----------

result_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Save results to the table

# COMMAND ----------

result_df.write.mode("overwrite").saveAsTable("dev.spark_db.flight_time")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.spark_db.flight_time