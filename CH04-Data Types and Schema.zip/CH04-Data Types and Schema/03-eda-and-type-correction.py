# Databricks notebook source
# MAGIC %md
# MAGIC ## 1. Read data from the sales_sample.csv file and analyse to identify problems

# COMMAND ----------

# MAGIC %md
# MAGIC 1.1 Define schema

# COMMAND ----------

file_schema = """ 
id int,
name string,
dop string,
phone long,
amount string,
date string
""" 


# COMMAND ----------

# MAGIC %md
# MAGIC 1.2 Read data

# COMMAND ----------

sales_raw_df = (
  spark.read.format("csv")
  .option("header","true")
  .schema(file_schema)
  .load("/Volumes/dev/spark_db/datasets/spark_programming/data/sales_sample.csv")
)

# COMMAND ----------

# MAGIC %md
# MAGIC 1.3 Describe the data

# COMMAND ----------

sales_raw_df.describe().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Prepare and clean the Dataframe using appropriate transformations

# COMMAND ----------

# MAGIC %md
# MAGIC 2.1 Transform

# COMMAND ----------

# DBTITLE 1,Cell 10
sales_df = sales_raw_df.selectExpr(
"cast(id as string) as transformation_id",
"name as customer_name",
"nvl(try_cast(dop as date),to_date(dop, 'dd-MM-yyyy')) as date_of_purchase",
"cast(phone as string) as customer_phone",
"cast(amount as long) as purchase_amount"
).filter("purchase_amount is not null and purchase_amount < 200000")

sales_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC 2.2 Verify statistics

# COMMAND ----------

# DBTITLE 1,Cell 12
sales_df.describe("purchase_amount").display()