# Databricks notebook source
# MAGIC %md
# MAGIC Requirement
# MAGIC Read data from flight_time and transform as below
# MAGIC
# MAGIC 1.Rename fl_date to dep_date
# MAGIC 2.Compute arr_date
# MAGIC 3.Following fields to represent full timestamp
# MAGIC - crs_dep_time
# MAGIC - dep_time
# MAGIC - crs_arr_time
# MAGIC - arr_time

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev.spark_db.flight_time order by DISTANCE desc

# COMMAND ----------

# MAGIC %md
# MAGIC Can we do it using select() or selectExpr() transformations?

# COMMAND ----------


flight_time_df = spark.read.table("dev.spark_db.flight_time")

fligth_time_1_df = (
    flight_time_df.selectExpr(
        "fl_date as dep_date",
        "case when arr_time < dep_time then fl_date + interval 1 day else fl_date end as arr_date",
        "dep_date + crs_dep_time as crs_dep_time",
        "dep_date + dep_time as dep_time",
        "arr_date + crs_arr_time as crs_arr_time",
        "arr_date + arr_time as arr_time",
        "op_carrier",
        "op_carrier_fl_num"
    )
)

fligth_time_1_df.where("op_carrier_fl_num = '1451' and dep_date = '2000-01-01'").display()

# COMMAND ----------

# MAGIC %md
# MAGIC Can we do it using withColumn() or withColumns()?

# COMMAND ----------

from pyspark.sql.functions import expr

fligth_time_2_df = (
    flight_time_df.withColumnRenamed("fl_date","dep_date")
    .withColumn("arr_date", expr("case when arr_time < dep_time then dep_date + interval 1 day else dep_date end"))
    .withColumns({
        "crs_dep_time": expr("dep_date + crs_dep_time"),
        "dep_time": expr("dep_date + dep_time"),
        "crs_arr_time": expr("arr_date + crs_arr_time"),
        "arr_time": expr("arr_date + arr_time"),
    })
)

fligth_time_2_df.where("op_carrier_fl_num = '1451' and dep_date = '2000-01-01'").display()

# COMMAND ----------

# MAGIC %md
# MAGIC Alternative approach to write expressions
# MAGIC - Why to use it?
# MAGIC - It gives access to column functions

# COMMAND ----------

from pyspark.sql.functions import *

flight_time_2_df = (
    flight_time_df.withColumnRenamed("fl_date","dep_date")
    .withColumn("arr_date", when(col("arr_time") < col("dep_time"), col("dep_date") + expr("interval 1 day")).otherwise(col("dep_date")))
    .withColumns({
        "crs_dep_time": col("dep_date") + col("crs_dep_time"),
        "dep_time": col("dep_date") + col("dep_time"),
        "crs_arr_time": col("arr_date") + col("crs_arr_time"),
        "arr_time": col("arr_date") + col("arr_time"),
        })
)
flight_time_2_df.where((col("op_carrier_fl_num")=="1451") & (col("dep_date")=="2000-01-01")).display()