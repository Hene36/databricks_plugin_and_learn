# Databricks notebook source
# MAGIC %md
# MAGIC ## 1. Read data from the apache-logs.txt file

# COMMAND ----------

# MAGIC %md
# MAGIC 1.1 Load and display the data

# COMMAND ----------

file_df = (spark.read.format("text").load("/Volumes/dev/spark_db/datasets/spark_programming/data/apache-logs.txt"))

display(file_df)

# COMMAND ----------

# MAGIC %md
# MAGIC 1.2 Print the schema

# COMMAND ----------

file_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC 2.2 Apply regular expression to parse the record

# COMMAND ----------

log_reg = r'^(\S+) (\S+) (\S+) \[([\w:/]+\s[+\-]\d{4})\] "(\S+) (\S+) (\S+)" (\d{3}) (\S+) "(\S+)" "([^"]*)'

# COMMAND ----------

from pyspark.sql.functions import regexp_extract

logs_df = (
    file_df.select(
        regexp_extract("value",log_reg,1).alias("ip_address"),
        regexp_extract("value",log_reg,4).alias("visit_timestamp"),
        regexp_extract("value",log_reg,6).alias("visit_resource"),
        regexp_extract("value",log_reg,10).alias("referring_url"),

    )
)

logs_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC 2.3 Refine results with further transformations

# COMMAND ----------

from pyspark.sql.functions import to_timestamp, substring_index

test_df = (
    logs_df.withColumns({
        "visit_timestamp": to_timestamp("visit_timestamp", "dd/MMM/yyyy:HH:mm:ss Z"),
        "referring_url": substring_index("referring_url","/",3)
    })
)
test_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Use AI to parse and extract the required information from unstructured data

# COMMAND ----------

# MAGIC %md
# MAGIC 3.1 Prepare an AI prompt to extract the required information

# COMMAND ----------

prompt = """
You will be provided with an Apache log file record. It is an unstructured text record. 
Each record represents some information for our website visits, such as what is the IP address of the visitor, 
What is the date and time of the visit, which resource was requested, and the URL of the referring website? 
You are asked to parse the log file record and extract the following fields.
ip_address: It is the IP address of the site visitor.
visit_timestamp: It is the date and time of the site visit. Parse and format the timestamp to YYYY-MM-DD HH:MI:SS Z
visit_resource: Which resource from our website was accessed?
referring_url: It is the clean URL of the referring website. When the actual referring URL is not given, 
you can extract the URL from the user agent. For cleaning the URL, you should take the values only up to the domain extension, 
such as .com, .in, .uk, etc.
Give only the final answer in the JSON format.
Record:
"""

# COMMAND ----------

from pyspark.sql.functions import *

result_df = (
    file_df.limit(20)
        .withColumn("prompt", concat(lit(prompt), col("value")))
        .withColumn("json_extract", expr("""
            ai_query(
                endpoint=> 'databricks-llama-4-maverick',
                request=> prompt,
                responseFormat=> 'struct<extract: struct<
                ip_address: string,
                visit_timestamp: string,
                visit_resource: string,
                referring_url: string
                >>')"""))
)

result_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC 4.3 Parse the JSON extract to individual columns

# COMMAND ----------

from pyspark.sql.functions import col,from_json,to_timestamp

extract_schema = 'ip_schema string, visit_timestamp string, visit_resource string, refering_url string'

final_result_df = (
    result_df.withColumn("json_extract", from_json(col("json_extract"),extract_schema))
    .selectExpr("json_extract.*")
    .withColumn("visit_timestamp", to_timestamp(col("visit_timestamp"),"yyyy-MM-dd HH:mm:ss Z"))
) 

final_result_df.display()