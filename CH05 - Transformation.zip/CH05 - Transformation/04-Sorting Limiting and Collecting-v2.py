# Databricks notebook source
# MAGIC %md
# MAGIC ## 1. Read data from flight_time table

# COMMAND ----------

flight_time_df = spark.read.table("dev.spark_db.flight_time")
flight_time_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Find the top 3 most delayed flights on 2000-01-16 from AUS to ORD Collect the results into a list and display the output as the following.
# MAGIC
# MAGIC - AA flight delayed by 5 minutes
# MAGIC - AA flight delayed by 2 minutes
# MAGIC - UA flight delayed by 2 minutes

# COMMAND ----------

from pyspark.sql.functions import expr

top_3_df = (
    flight_time_df.where("FL_DATE = '2000-01-16' and origin = 'AUS' and dest = 'ORD'")
        .withColumn("delayed_arrival", expr("arr_time - crs_arr_time"))
        .orderBy("delayed_arrival", ascending=False)
        .limit(3)
)

top_3_list_of_rows = top_3_df.collect()

# COMMAND ----------

# MAGIC %md
# MAGIC 2.2 Make a list of dictionary from a list of rows

# COMMAND ----------

top3_list = [row.asDict() for row in top3_df_list_of_rows]

# COMMAND ----------

# MAGIC %md
# MAGIC 2.3 Print the result in desired format

# COMMAND ----------

for row in top_3_list_of_rows:
    row_dict = row.asDict()
    print(row_dict["OP_CARRIER"] 
          + " flight delayed by "
          + str(row_dict["delayed_arrival"].total_seconds()/60)
          + " minutes")

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Find the third most delayed flights on 2000-01-16 from AUS to ORD

# COMMAND ----------

top_3rd_df = (
    flight_time_df.where("FL_DATE = '2000-01-16' and origin = 'AUS' and dest = 'ORD'")
    .withColumn("delayed_arrivals", expr("arr_time - crs_arr_time"))
    .orderBy("delayed_arrivals", ascending=False)
    .limit(3)
    .offset(2)
)

top_3rd_df.display()