# Databricks notebook source
data_schema = "id int, source string, destination string, distance string"

data_list = [
    (101, "Edmonton", "Calgary","330"),
    (102, "Edmonton","Vancouver","550"),
    (102, "Edmonton", "Vancouver","550"),
    (103, "Toronto","Ottawa","400"),
    (104, "Toronto","Ottawa","400"),
    (105, "Winnepeg","Regina","550"),
    (105, "Winnepeg","Regina","550")
]

df = spark.createDataFrame(data =data_list, schema=data_schema)

# COMMAND ----------

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC 2.1 Using a single filter

# COMMAND ----------

df.filter("source ='Edmonton' and destination='Vancouver'").display()

# COMMAND ----------

# MAGIC %md
# MAGIC 2.2 Using two filters

# COMMAND ----------

df.filter("source='Edmonton'").filter('destination = "Vancouver"').display()

# COMMAND ----------

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC 2.3 Using a col function expression

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

df.filter((col("source")=='Edmonton') & (col("destination")=='Vancouver')).display()

# COMMAND ----------

# MAGIC %md
# MAGIC 2.4 Using a dataframe qualifier expression

# COMMAND ----------

# DBTITLE 1,Cell 12
df.filter((df.source == "Edmonton") & (df.destination == "Banglore")).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Remove duplicate records from your dataframe

# COMMAND ----------

df.display()

# COMMAND ----------

df.distinct().display()

# COMMAND ----------

df.dropDuplicates(["id","source","destination"]).display()